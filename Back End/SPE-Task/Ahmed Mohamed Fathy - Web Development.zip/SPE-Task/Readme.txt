import spe_task.sql to your database 
the database name spe_task
the table name spe_form

move the extreacted folder to your localjost
username : root
password: 

and then open the task from http://localhost/spe-task/