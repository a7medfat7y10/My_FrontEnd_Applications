<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title><?php getTitle();?></title>
        <link rel="stylesheet" href="<?php echo $css ; ?>bootstrap.css">
        <!-- normalize library  for good reset-->
        <link rel="stylesheet" href="<?php echo $css ; ?>normalize.css">
        <!-- font-awesome icons library -->
        <link rel="stylesheet" href="<?php echo $css ; ?>font-awesome.min.css">
        <!-- Main Css File -->
        <link rel="stylesheet" href="<?php echo $css ; ?>backend.css?v=<?php echo time(); ?>">
    </head>
    <body>
        
   