 <!-- #################### Start CopyRight #################### -->
    <section class="copyright text-center">
        <div class="container">
            <p>&copy; Designed and Developed By <span>EEGS SUSC</span> IT Team <?php echo date("Y");?></p>
            
        </div>
        
    </section>
    <!-- #################### End CopyRight #################### -->
    </body>
    <script src="<?php echo $js ; ?>jquery-1.11.3.min.js"></script>
    <script src="<?php echo $js ; ?>html5shiv.min.js"></script>
    <script src="<?php echo $js ; ?>respond.min.js"></script>
    <!-- bootstrap library -->
    <script src="<?php echo $js ; ?>bootstrap.min.js"></script>
    <!-- Main JavaScript File -->
    <script src="<?php echo $js ; ?>backend.js?v=<?php echo time(); ?>"></script>
</html>